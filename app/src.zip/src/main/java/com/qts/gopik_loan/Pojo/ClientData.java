package com.qts.gopik_loan.Pojo;

public class ClientData {
    private String caseId;

    public ClientData(String caseId)
    {

        this.caseId = caseId;
    }
}
