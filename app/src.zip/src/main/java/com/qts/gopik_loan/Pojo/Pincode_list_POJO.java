package com.qts.gopik_loan.Pojo;

public class Pincode_list_POJO {
    private String prod_brand;
    private String user_pincode;




    public Pincode_list_POJO(String prod_brand ,String user_pincode ) {

        this.prod_brand = prod_brand;
        this.user_pincode = user_pincode;


    }
}
