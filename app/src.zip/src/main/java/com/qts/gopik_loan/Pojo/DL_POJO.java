package com.qts.gopik_loan.Pojo;

public class DL_POJO {
    private String dlNo;
    private String dob;
    private String additionalDetails;
    private String consent;



    public DL_POJO(String dlNo,String dob,String additionalDetails,String consent
            ) {
        this.dlNo = dlNo;
        this.dob = dob;
        this.additionalDetails = additionalDetails;
        this.consent = consent;




    }
}
