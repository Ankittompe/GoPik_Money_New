package com.qts.gopik_loan.Pojo;

public class RegistrationPOJO {
    private String name;
    private String mobile;



    public RegistrationPOJO(String name , String mobile) {
        this.name = name;
        this.mobile = mobile;

    }
}
