package com.qts.gopik_loan.Pojo;

public class Apiget_panid_details_POJO {
    private String pan_no;




    public Apiget_panid_details_POJO(String pan_no ) {

        this.pan_no = pan_no;


    }
}
