package com.qts.gopik_loan.Pojo;

public class Wallet_balance_POJO {
    private String user_code;




    public Wallet_balance_POJO(String user_code ) {

        this.user_code = user_code;


    }
}
