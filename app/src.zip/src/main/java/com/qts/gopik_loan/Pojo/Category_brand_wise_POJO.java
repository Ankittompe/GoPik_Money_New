package com.qts.gopik_loan.Pojo;

public class Category_brand_wise_POJO {
    private String brand;




    public Category_brand_wise_POJO(String brand ) {

        this.brand = brand;


    }

}
