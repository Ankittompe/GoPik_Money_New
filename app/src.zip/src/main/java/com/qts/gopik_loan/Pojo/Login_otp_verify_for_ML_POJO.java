package com.qts.gopik_loan.Pojo;

public class Login_otp_verify_for_ML_POJO {
    private String mobile;
    private String otp;


    public Login_otp_verify_for_ML_POJO(String mobile,String otp) {

        this.mobile = mobile;
        this.otp = otp;


    }
}
