package com.qts.gopik_loan.Pojo;

public class Get_ML_SubCat_List_POJO {
    private String brand;




    public Get_ML_SubCat_List_POJO(String brand ) {

        this.brand = brand;


    }

}
