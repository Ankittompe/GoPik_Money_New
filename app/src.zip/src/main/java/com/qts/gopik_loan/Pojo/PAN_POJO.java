package com.qts.gopik_loan.Pojo;

public class PAN_POJO {
    private String consent;
    private String pan;


    public PAN_POJO(String consent,String pan) {
        this.consent = consent;
         this.pan = pan;


    }
}
