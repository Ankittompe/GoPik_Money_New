package com.qts.gopik_loan.Pojo;

public class PASSPORT_POJO {
    private String consent;
    private String fileNo;
    private String dob;
    private String passportNo;
    private String doi;
    private String name;


    public PASSPORT_POJO(String consent,String fileNo,String dob,String passportNo,String doi
            ,String name) {
        this.consent = consent;
        this.fileNo = fileNo;
        this.dob = dob;
        this.passportNo = passportNo;
        this.doi = doi;
        this.name = name;



    }
}
