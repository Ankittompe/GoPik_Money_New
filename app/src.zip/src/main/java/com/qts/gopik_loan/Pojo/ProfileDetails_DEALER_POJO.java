package com.qts.gopik_loan.Pojo;


public class ProfileDetails_DEALER_POJO {
    private String mobile_number;
    private String token;



    public ProfileDetails_DEALER_POJO(String mobile_number, String token ) {

        this.mobile_number = mobile_number;
        this.token = token;

    }



}
