package com.qts.gopik_loan.Model;

public class Login_actPOJO {
    private String user_mobile;





    public Login_actPOJO(String user_mobile) {

        this.user_mobile = user_mobile;



    }
}
