package com.qts.gopik_loan.Pojo;

public class Dealer_Subuser_fetch_POJO {
    private String dealer_code;




    public Dealer_Subuser_fetch_POJO(String dealer_code ) {

        this.dealer_code = dealer_code;


    }
}
