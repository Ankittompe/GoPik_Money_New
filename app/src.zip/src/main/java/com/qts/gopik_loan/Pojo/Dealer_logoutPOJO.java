package com.qts.gopik_loan.Pojo;

public class Dealer_logoutPOJO {
    private String brand;
    private String number;
    private String code;




    public Dealer_logoutPOJO(String brand, String number,String code) {

        this.brand = brand;
        this.number = number;
        this.code = code;


    }

}
