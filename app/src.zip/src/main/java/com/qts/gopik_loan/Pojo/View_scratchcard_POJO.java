package com.qts.gopik_loan.Pojo;

public class View_scratchcard_POJO {
    private String user_code;




    public View_scratchcard_POJO(String user_code ) {

        this.user_code = user_code;


    }
}
