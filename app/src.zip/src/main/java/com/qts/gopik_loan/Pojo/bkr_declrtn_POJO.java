package com.qts.gopik_loan.Pojo;

public class bkr_declrtn_POJO {
    private String mobile;
    private String token;
    private String declrtn;


    public bkr_declrtn_POJO(String mobile,String token,String declrtn) {

        this.mobile = mobile;
        this.token = token;
        this.declrtn = declrtn;


    }

}
