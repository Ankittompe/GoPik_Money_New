package com.qts.gopik_loan.Pojo;

public class Get_voterid_details_POJO {
    private String epic_no;




    public Get_voterid_details_POJO(String epic_no ) {

        this.epic_no = epic_no;


    }
}
