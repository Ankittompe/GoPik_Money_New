package com.qts.gopik_loan.Pojo;

public class Store_panid_details_POJO {
    private String cust_code;
    private String pan_no;
    private String pan_name;



    public Store_panid_details_POJO(String cust_code, String pan_no , String pan_name ) {

        this.cust_code = cust_code;
        this.pan_no = pan_no;
        this.pan_name = pan_name;


    }


}
