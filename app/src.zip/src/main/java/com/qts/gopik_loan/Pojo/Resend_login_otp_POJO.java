package com.qts.gopik_loan.Pojo;

public class Resend_login_otp_POJO {
    private String mobile_number;


    public Resend_login_otp_POJO(String mobile_number) {

        this.mobile_number = mobile_number;



    }
}
