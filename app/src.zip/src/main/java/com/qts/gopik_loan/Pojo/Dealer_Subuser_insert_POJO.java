package com.qts.gopik_loan.Pojo;

public class Dealer_Subuser_insert_POJO {
    private String dealer_code;
    private String dealer_name;
    private String subdealer_nm;
    private String subdealer_mbl;
    private String role;




    public Dealer_Subuser_insert_POJO(String dealer_code ,String dealer_name,String subdealer_nm ,String subdealer_mbl
            ,String role) {

        this.dealer_code = dealer_code;
        this.dealer_name = dealer_name;
        this.subdealer_nm = subdealer_nm;
        this.subdealer_mbl = subdealer_mbl;
        this.role = role;

    }

}
