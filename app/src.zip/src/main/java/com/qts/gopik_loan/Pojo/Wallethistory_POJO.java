package com.qts.gopik_loan.Pojo;

public class Wallethistory_POJO {
    private String user_code;




    public Wallethistory_POJO(String user_code ) {

        this.user_code = user_code;


    }
}
