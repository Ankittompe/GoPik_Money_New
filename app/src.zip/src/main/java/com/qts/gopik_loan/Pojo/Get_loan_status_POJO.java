package com.qts.gopik_loan.Pojo;

public class Get_loan_status_POJO {
    private String customer_code;




    public Get_loan_status_POJO(String customer_code ) {

        this.customer_code = customer_code;


    }
}
