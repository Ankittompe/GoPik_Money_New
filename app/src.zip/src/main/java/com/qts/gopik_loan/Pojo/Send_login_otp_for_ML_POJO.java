package com.qts.gopik_loan.Pojo;

public class Send_login_otp_for_ML_POJO {
    private String mobile;



    public Send_login_otp_for_ML_POJO(String mobile) {

        this.mobile = mobile;


    }

}
