package com.qts.gopik_loan.Pojo;

public class Product_details_POJO {
    private String product_type;
    private String product_id;





    public Product_details_POJO(String product_type ,String product_id) {

        this.product_type = product_type;
        this.product_id = product_id;




    }

}
