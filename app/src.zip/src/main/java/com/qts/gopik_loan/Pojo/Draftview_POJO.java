package com.qts.gopik_loan.Pojo;

public class Draftview_POJO {
    private String customer_code;



    public Draftview_POJO(String customer_code){
        this.customer_code = customer_code;


    }
}
