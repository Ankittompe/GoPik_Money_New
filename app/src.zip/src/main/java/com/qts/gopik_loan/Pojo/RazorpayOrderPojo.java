package com.qts.gopik_loan.Pojo;

public class RazorpayOrderPojo {
    private String amount;
    private String currency;

    public RazorpayOrderPojo(String amount, String currency){
        this.amount = amount;
        this.currency = currency;
    }

}
