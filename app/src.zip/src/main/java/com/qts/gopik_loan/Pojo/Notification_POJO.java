package com.qts.gopik_loan.Pojo;

public class Notification_POJO {
    private String brand;
    private String state;




    public Notification_POJO(String brand,String state ) {
        this.brand = brand;
        this.state = state;


    }
}
