package com.qts.gopik_loan.Model;

public class ADDRESS_PAYLOAD {
}
