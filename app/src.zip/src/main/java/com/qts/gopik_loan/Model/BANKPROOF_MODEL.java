package com.qts.gopik_loan.Model;

public class BANKPROOF_MODEL {
}
