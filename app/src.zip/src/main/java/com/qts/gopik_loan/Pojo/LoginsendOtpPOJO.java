package com.qts.gopik_loan.Pojo;

public class LoginsendOtpPOJO {
    private String mobile_number;




    public LoginsendOtpPOJO(String mobile_number ) {

        this.mobile_number = mobile_number;


    }

}
