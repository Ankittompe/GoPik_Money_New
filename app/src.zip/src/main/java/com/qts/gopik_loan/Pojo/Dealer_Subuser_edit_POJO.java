package com.qts.gopik_loan.Pojo;

public class Dealer_Subuser_edit_POJO {
    private String subdealer_id;
    private String subdealer_nm;
    private String subdealer_mbl;





    public Dealer_Subuser_edit_POJO(String subdealer_id, String subdealer_nm , String subdealer_mbl ) {

        this.subdealer_id = subdealer_id;
        this.subdealer_nm = subdealer_nm;
        this.subdealer_mbl = subdealer_mbl;



    }
}
