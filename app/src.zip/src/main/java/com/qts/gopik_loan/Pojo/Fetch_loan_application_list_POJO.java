package com.qts.gopik_loan.Pojo;

public class Fetch_loan_application_list_POJO {   private String user_code;




    public Fetch_loan_application_list_POJO(String user_code ) {

        this.user_code = user_code;


    }

}
