package com.qts.gopik_loan.Pojo;

public class GetCatproductPojo {
    private String category_type;
    private String cat_name;
    private String brand;




    public GetCatproductPojo(String category_type ,String cat_name,String brand ) {

        this.category_type = category_type;
        this.cat_name = cat_name;
        this.brand = brand;


    }

}
