package com.qts.gopik_loan.Pojo;

public class Get_wallet_details_POJO {
    private String user_code;
    private String wallet_type;
    private String customer_code;




    public Get_wallet_details_POJO(String user_code,String wallet_type,String customer_code ) {

        this.user_code = user_code;
        this.wallet_type = wallet_type;
        this.customer_code = customer_code;


    }
}
