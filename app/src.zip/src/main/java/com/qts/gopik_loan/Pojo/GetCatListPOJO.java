package com.qts.gopik_loan.Pojo;

public class GetCatListPOJO {
    private String category_type;




    public GetCatListPOJO(String category_type ) {

        this.category_type = category_type;


    }
}
