package com.qts.gopik_loan.Pojo;

public class LogInOtpVerifyPOJO {

    private String mobile_number;
    private String otp;



    public LogInOtpVerifyPOJO(String mobile_number, String otp ) {

        this.mobile_number = mobile_number;
        this.otp = otp;

    }
}
