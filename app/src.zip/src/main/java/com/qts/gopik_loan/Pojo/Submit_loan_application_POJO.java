package com.qts.gopik_loan.Pojo;

public class Submit_loan_application_POJO {

    private String customer_code;
    private String user_code;



    public Submit_loan_application_POJO( String customer_code,String user_code
                                 ) {


        this.customer_code = customer_code;
        this.user_code = user_code;

    }
}
