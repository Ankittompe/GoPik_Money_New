package com.qts.gopik_loan.Pojo;

public class Get_wallet_txn_POJO {
    private String user_code;
    private String wallet_type;





    public Get_wallet_txn_POJO(String user_code, String wallet_type ) {

        this.user_code = user_code;
        this.wallet_type = wallet_type;


    }
}
