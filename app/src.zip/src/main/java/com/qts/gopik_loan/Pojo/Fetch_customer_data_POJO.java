package com.qts.gopik_loan.Pojo;

public class Fetch_customer_data_POJO {
    private String cust_code;





    public Fetch_customer_data_POJO(String cust_code ) {

        this.cust_code = cust_code;



    }
}
