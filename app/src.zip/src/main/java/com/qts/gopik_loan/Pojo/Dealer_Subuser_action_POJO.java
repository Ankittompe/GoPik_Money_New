package com.qts.gopik_loan.Pojo;

public class Dealer_Subuser_action_POJO { private String subdealer_id;
    private String action;





    public Dealer_Subuser_action_POJO(String subdealer_id, String action ) {

        this.subdealer_id = subdealer_id;
        this.action = action;


    }

}
