package com.qts.gopik_loan.Dealer_Activity;

public class Cash_Details {
}
