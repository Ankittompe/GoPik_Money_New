package com.qts.gopik_loan.Pojo;

public class OtpVerificationPOJO {

    private String mobile;
    private String otp;



    public OtpVerificationPOJO(String mobile, String otp ) {

        this.mobile = mobile;
        this.otp = otp;

    }
}
