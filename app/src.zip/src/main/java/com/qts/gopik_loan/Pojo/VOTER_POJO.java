package com.qts.gopik_loan.Pojo;

public class VOTER_POJO {
    private String consent;
    private String epic_no;


    public VOTER_POJO(String consent,String epic_no) {
        this.consent = consent;
        this.epic_no = epic_no;


    }
}
