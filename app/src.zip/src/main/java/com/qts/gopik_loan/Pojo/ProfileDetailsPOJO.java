package com.qts.gopik_loan.Pojo;

public class ProfileDetailsPOJO {

    private String mobile_number;
    private String token;



    public ProfileDetailsPOJO(String mobile_number, String token ) {

        this.mobile_number = mobile_number;
        this.token = token;

    }
}
