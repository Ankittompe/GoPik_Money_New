package com.qts.gopik_loan.Pojo;

public class Banner_POJO {
    private String brand;




    public Banner_POJO(String brand ) {

        this.brand = brand;


    }
}
