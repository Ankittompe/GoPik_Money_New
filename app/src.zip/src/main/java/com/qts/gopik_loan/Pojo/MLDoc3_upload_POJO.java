package com.qts.gopik_loan.Pojo;

public class MLDoc3_upload_POJO {
    private String custcode;
    private String emp_type;
    private String emp_decltn;

    public MLDoc3_upload_POJO(String custcode, String emp_type, String emp_decltn) {

        this.custcode = custcode;
        this.emp_type = emp_type;
        this.emp_decltn = emp_decltn;


    }
}
