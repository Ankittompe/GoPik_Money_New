package com.qts.gopik_loan.Pojo;

public class Broker_profile_details_POJO {

    private String mobile_number;
    private String token;



    public Broker_profile_details_POJO(String mobile_number, String token ) {

        this.mobile_number = mobile_number;
        this.token = token;

    }
}
