package com.qts.gopik_loan.Pojo;

public class Aadhaarverification_POJO {
    private String aadhaarNo;
    private String consent;
    private String accessKey;
    private ClientData clientData;
    public Aadhaarverification_POJO(String aadhaarNo,String consent,String accessKey,ClientData clientData) {
        this.aadhaarNo = aadhaarNo;
        this.consent = consent;
        this.accessKey = accessKey;
        this.clientData = clientData;






    }


}
