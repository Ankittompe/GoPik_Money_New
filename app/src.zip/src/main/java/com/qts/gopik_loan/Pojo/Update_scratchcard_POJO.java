package com.qts.gopik_loan.Pojo;

public class Update_scratchcard_POJO {
    private String id;




    public Update_scratchcard_POJO(String id ) {

        this.id = id;


    }
}
