package com.qts.gopik_loan.Retro;


public interface ApiConstraints {
    String BASE_URL = "https://api.gopikmoney.com/public/api/";
    String RAZORPAY_PAYMENT_INVOICE_CREATION = "https://api.razorpay.com/v1/";
     String PINCODE="http://www.postalpincode.in/api/";
    String STATE="https://ifsc.razorpay.com/";
    String pan= "https://testapi.karza.in/v2/";
    String voter="https://testapi.karza.in/v2/";
   String passport="https://testapi.karza.in/v3/";
    String dl="https://testapi.karza.in/v3/";
    String adharconsent= "https://testapi.karza.in/v3/";
    String aadharcardverification="https://testapi.karza.in/v2/";
    String pic="https://demonuts.com/Demonuts/JsonTest/Tennis/";

   String delaer="https://api.gopikmoney.com/public/api/";
}


